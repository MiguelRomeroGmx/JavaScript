'use strict';

module.exports = {};
module.exports.filler = require('./plugin.filler');
module.exports.legend = require('./plugin.legend');
module.exports.title = require('./plugin.title');
